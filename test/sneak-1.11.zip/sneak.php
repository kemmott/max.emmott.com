<?php

 /***********************************************************************
 * sneak.php - v 1.11 - 2002/02/21
 *
 * SNEAK: Snarkles.Net Encryption Assortment Kit
 * =============================================
 * Send and decode messages using a number of different methods
 *
 * Please forward any suggestions, problems, improvements, etc. to the 
 * e-mail address below. Thanks! :D
 *
 * Copyright (c) 2000, 2001, 2002 snarkles (webgeek@snarkles.net)
 * Distributed under the GNU/GPL license (see http://www.gnu.org/copyleft/)
 ************************************************************************/
 /************************************************************************
 * Changelog
 * =========
 * v 1.11 - 2002/02/21:
 * - Cleaned up code some--now all chunk_splitting and str_replacing is 
 *   done within the functions, rather than during the switch statement
 * - Specified CRYPT_STD_DES in crypt() function, to fix problem with PHP 4.1.2
 *
 * v 1.10 - 2002/02/17:
 * - Added bin2hex, hex2bin, and pig latin functions
 *
 * v 1.00 - 2002/02/15:
 * - Nothing yet, but I'm sure that'll CHANGE. Ha! Get it? ;)
 *************************************************************************/
  $version = "1.11";

  // You can alter the HTML below to make this script fit more inline with 
  // the rest of your site.

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html>
 <head>
  <title>SNEAK: Snarkles.Net Encryption Assortment Kit</title>
  <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
  <style type="text/css">
  <!--
    body { font-family: "arial", "helvetica", sans-serif; font-size: 10pt; }
  -->
  </style>
 </head>
 <body>

<?php

  // Declare some functions for encryption not included in PHP

    function asc2bin($str) {
      $text_array = explode("\r\n", chunk_split($str, 1));
      for ($n = 0; $n < count($text_array) - 1; $n++) {
        $newstring .= substr("0000".base_convert(ord($text_array[$n]), 10, 2), -8);
      }
      $newstring = chunk_split($newstring, 8, " ");
      return $newstring;
    }

    function bin2asc($str) {
      $str = str_replace(" ", "", $str);
      $text_array = explode("\r\n", chunk_split($str, 8));
      for ($n = 0; $n < count($text_array) - 1; $n++) {
        $newstring .= chr(base_convert($text_array[$n], 2, 10));
      }
      return $newstring;
    }

    // Made this alias because "bin2hex" would be confusing in the context of this script :P
    function asc2hex($str) {
      return chunk_split(bin2hex($str), 2, " ");
    }

    function hex2asc($str) {
      $str = str_replace(" ", "", $str);
      for ($n=0; $n<strlen($str); $n+=2) {
        $newstring .=  pack("C", hexdec(substr($str, $n, 2)));
      }
      return $newstring;
    }

    function binary2hex($str) {
      $str = str_replace(" ", "", $str);
      $text_array = explode("\r\n", chunk_split($str, 8));
      for ($n = 0; $n < count($text_array) - 1; $n++) {
        $newstring .= base_convert($text_array[$n], 2, 16);
      }
      $newstring = chunk_split($newstring, 2, " ");
      return $newstring;
    }

    function hex2binary($str) {
      $str = str_replace(" ", "", $str);
      $text_array = explode("\r\n", chunk_split($str, 2));
      for ($n = 0; $n < count($text_array) - 1; $n++) {
        $newstring .= substr("0000".base_convert($text_array[$n], 16, 2), -8);
      }
      $newstring = chunk_split($newstring, 8, " ");
      return $newstring;
    }

    function l33t($str) {
      $from = 'ieastoIEASTO';
      $to = '134570134570';
      $newstring = strtr($str, $from, $to);
      return $newstring;
    }

    function del33t($str) {
      $from = '134570';
      $to = 'ieasto';
      $newstring = strtr($str, $from, $to);
      return $newstring;
    }

    function igpay($str) {
      $text_array = explode(" ", $str);
      for ($n = 0; $n < count($text_array); $n++) {
        $newstring .= substr($text_array[$n], 1) . substr($text_array[$n], 0, 1) . "ay ";
      }
      return $newstring;
    }

    function unigpay($str) {
      $text_array = explode(" ", $str);
      for ($n = 0; $n < count($text_array); $n++) {
        $newstring .= substr($text_array[$n], -3, 1) . substr($text_array[$n], 0, strlen($text_array[$n]) - 3) . " ";
      }
      return $newstring;
    }

    function rot13($str) {
        $from = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $to   = 'nopqrstuvwxyzabcdefghijklmNOPQRSTUVWXYZABCDEFGHIJKLM';
        $newstring = strtr($str, $from, $to);
        return $newstring;
    }

  // Check to see if form has been submitted yet

  if(isset($submit)) {

    // Yes, so make sure they filled something in

    if($text == '') {
      die("<p>Fill in the form, dinglefritz! ;)</p>\n");
    }

    // Looks good, so clean up data

    $text = stripslashes(urldecode(strip_tags($text)));

    // Make copy of original text for later display

    $orig_text = $text;

    // De/Encrypt based on selection in form

    switch ($cryptmethod) {
     case "asc2bin":
       $text = asc2bin($text);
       break;
     case "asc2hex":
       $text = asc2hex($text);
       break;
     case "bin2asc":
       $text = bin2asc($text);
       break;
     case "hex2asc":
       $text = hex2asc($text);
       break;
     case "bin2hex":
       $text = binary2hex($text);
       break;
     case "hex2bin":
       $text = hex2binary($text);
       break;
     case "backwards":
       $text = strrev($text);
       break;
     case 'b64dec':
       $text = base64_decode($text);
       break;
     case 'b64enc':
       $text = base64_encode($text);
       break;
     case 'crypt':
       $text = crypt($text, 'CRYPT_STD_DES');
       break;
     case "l33t":
       $text = l33t($text);
       break;
     case "del33t":
       $text = del33t($text);
       break;
     case 'md5':
       $text = md5($text);
       break;
     case 'igpay':
       $text = igpay($text);
       break;
     case 'unigpay':
       $text = unigpay($text);
       break;
     case "rot-13":
       $text = rot13($text);
       break;
     case 'urldec':
       $text = urldecode($text);
       break;
     case 'urlenc':
       $text = urlencode($text);
       break;
     default:
       die("<p>That encryption type is not supported.</p>\n");
    } // end switch

  // Display result to the screen

  echo("<p>$orig_text converts to:</p>\n");
  echo("<p>$text</p>\n");

  } // end if

?>

 <!-- begin form -->
 <center>
  <form action="<?php echo($PHP_SELF); ?>" method="post">
   <textarea name="text" rows="5" cols="50"></textarea><br />
   <select name="cryptmethod">
    <option value="asc2bin">ASCII to Binary</option>
    <option value="bin2asc">Binary to ASCII</option>
    <option value="asc2hex">ASCII to Hex</option>
    <option value="hex2asc">Hex to ASCII</option>
    <option value="bin2hex">Binary to Hex</option>
    <option value="hex2bin">Hex to Binary</option>
    <option value="backwards">Backwards</option>
    <option value="b64dec">Base 64 Decode</option>
    <option value="b64enc">Base 64 Encode</option>
    <option value="crypt">DES Crypt (one way)</option>
    <option value="l33t">l33t 5p34k 3ncryp7</option>
    <option value="del33t">l33t 5p34k d3cryp7</option>
    <option value="md5">MD5 Crypt (one way)</option>
    <option value="igpay">Igpay Atinlay</option>
    <option value="unigpay">Un-Pig Latin</option>
    <option value="rot-13">ROT-13</option>
    <option value="urldec">URL Decode</option>
    <option value="urlenc">URL Encode</option>
   </select><br />
   <input type="submit" name="submit" value="OK" />
   <input type="reset" value="Clear" />
  </form>
 </center>

  <!-- begin footer; it would be nice if you would leave this on. ;) -->
  <center>
   <p>
      <font size="1">Fine Print Shtuff:<br />
      SNEAK: Snarkles.Net Encryption Assortment Kit - Version <?php echo($version); ?><br />
      &copy; 2000, 2001, 2002 <a href="http://snarkles.net">snarkles</a><br />
      Download a copy <a href="http://snarkles.net/scripts/sneak/sneak-<?php echo($version); ?>.zip">here</a></font>
   </p>
  </center>

 </body>
</html>